<?php
class FieldMasterController extends CI_Controller  {
    var $base;
    var $css;

    function FieldMasterController()
	{
		parent::__construct();
		$this->base = $this->config->item('base_url');
	    $this->css = $this->config->item('css');
	}

	function get($name)
	{
		$data['css'] = $this->css;
		$data['base'] = $this->base;
		$data['mytitle'] = '��ӭ�������ҳ��';
		$data['mytext'] = "Hello, $name, now we're getting top 5 datas from !";
		
		$data['result'] = $this->getData();

		$this->load->view('field_master_view', $data);
	}

	function getData() {
		$this->load->model('field_master');
		$result = $this->field_master->get_data_top5();
		return $result;
	}
}
