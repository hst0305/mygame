<?php
class GetFieldMaster extends CI_Controller  {
    var $base;
    var $css;

    function GetFieldMaster()
	{
		parent::__construct();
		$this->base = $this->config->item('base_url');
	    $this->css = $this->config->item('css');
	}

	function index()
	{
		$data['css'] = $this->css;
		$data['base'] = $this->base;
		$data['mytitle'] = 'Welcome to this site';
		$data['mytext'] = "Hello,  now we're getting datas from FieldMaste !";
		
		$data['result'] = $this->_getData();

		$this->load->view('field_master_view', $data);
	}

	function _getData() {
		$this->load->model('field_master');
		$result = $this->field_master->get_field_master_top5();
		return $result;
	}
}
