<?php
class GetRankList extends CI_Controller  {

    function GetRankList()
	{
		parent::__construct();
		//$this->output->parse_exec_vars = false;
		$this->load->helper('json_multi');
		$this->load->helper('array_convert');
		$this->load->helper('header_check');
	}

	function index()
	{
		error_log('test',3,'D:\errorLog.txt');

		$data = array();
				
		$rankList = $this->_getRankList();

		$data['rankList'] = $rankList;

		$this->output->set_header("Content-Type: application/x-javascript; charset=utf-8"); 

		$this->output->set_output(json_encode_multi($data));
		
	}

	function _getRankList() {
		$this->load->model('rank_list');
		$result = $this->rank_list->get_rank_list();
		return $result;
	}
}
