<?php
class InsertRankList extends CI_Controller  {

    function InsertRankList()
	{
		parent::__construct();
		$this->load->helper('json_multi');
		$this->load->helper('model_validation');
		$this->load->helper('header_check');
		$this->load->database();
	}

	function index()
	{
		try{
			
			//$validation_result = $this->form_validation->run();

			$data = array();

			$count = //$_POST['count'];
			json_decode($this->input->post('count',TRUE),true);

			$seconds = //$_POST['seconds'];
			json_decode($this->input->post('seconds',TRUE),true);

			error_log($count.'-'.$seconds,3,'D:\errorLog.txt');

			$newRank = array(
				'count' => $count,
				'seconds' => $seconds
			);

			$this->db->trans_begin();

			$this->load->model('rank_list', '', TRUE);

			$flag = $this->rank_list->insert_rank($newRank);

			if (!$flag) {
				
				$this->db->trans_rollback();
				$data['error'] = "400:Update Error";
				
			} elseif ($this->db->trans_status() === FALSE) {
				
				$this->db->trans_rollback();
				$data['error'] = "400:Update Error";
				
			} else {
				
				$this->db->trans_commit();
			
				$data['error'] = "";
			}
					
			
			$this->output->set_header("Content-Type: application/x-javascript; charset=utf-8"); 
		
			$this->output->set_output(json_encode_multi($data));

		
		} catch (Exception $e) {

		    $this->db->trans_rollback();

			set_status_header(400);
		}
		
	}

	
}
