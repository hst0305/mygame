<?php
class shopDetail extends CI_Controller  {
    var $base;
    var $css;

    function shopDetail()
	{
		parent::__construct();
		$this->base = $this->config->item('base_url');
	    $this->css = $this->config->item('css');
	}

	function index($detail_id)
	{
		$data['css'] = $this->css;
		$data['base'] = $this->base;
		
		$data['detail'] = $this->_getData($detail_id);

		$this->load->view('shop_detail_view', $data);
	}
	
	function _getData($detail_id) {
		$this->load->model('shop_detail');
		$result = $this->shop_detail->get_shop_detail($detail_id);
		return $result;
	}
}
