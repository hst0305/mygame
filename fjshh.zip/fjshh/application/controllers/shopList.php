<?php
class shopList extends CI_Controller  {
    var $base;
    var $css;

    function shopList()
	{
		parent::__construct();
		$this->base = $this->config->item('base_url');
	    $this->css = $this->config->item('css');
	}

	function index($type,$category_id)
	{
		$data['css'] = $this->css;
		$data['base'] = $this->base;
		$data['home'] ='index.php/shopList/index/1';
		$data['eat'] ='index.php/shopList/index/2';
		$data['fun'] ='index.php/shopList/index/2';
		$data['service'] ='index.php/shopList/index/2';
		$data['area'] ='index.php/shopList/index/2';
		error_log($type,3,'D:\errorLog.txt');
		if($type == 1) {
			$data['category2'] = $this->_getListByCategory(3);
			$this->load->view('shop_list_view1', $data);
		} else if($type == 2) {
		
			$data['category3'] = $this->_getListByCategory(3);
			$data['category4'] = $this->_getListByCategory(4);
			$data['category5'] = $this->_getListByCategory(5);
			$this->load->view('shop_list_view2', $data);
		}  else if($type == 0) {
			$data['category'] = $this->_getMoreListByCategory($category_id);
			$data['category_name'] = $this->_getCategoryName($category_id);
			$this->load->view('shop_list_more_view', $data);
		}
	}
	
	function _getList($type) {
		$this->load->model('shop_list');
		$result = $this->shop_list->get_shop_list($type);
		return $result;
	}
	
	function _getListByCategory($category_id) {
		$this->load->model('shop_list');
		$result = $this->shop_list->get_shop_list_category($category_id);
		return $result;
	}
	
	function _getMoreListByCategory($category_id) {
		$this->load->model('shop_list');
		$result = $this->shop_list->get_shop_list_more($category_id);
		return $result;
	}
	
	function _getCategoryName($category_id) {
		$this->load->model('shop_category');
		$row= $this->shop_category->get_name_by_id($category_id);
		return $row;
	}
}
