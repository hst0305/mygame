<?php
class Start extends CI_Controller  {
    var $base;
    var $css;

    function Start()
	{
		parent::__construct();
		$this->base = $this->config->item('base_url');
	    $this->css = $this->config->item('css');
	}

	function hello($name)
	{
		$data['css'] = $this->css;
		$data['base'] = $this->base;
		$data['mytitle'] = 'Welcome to this site';
		$data['mytext'] = "Hello, $name, now we're getting dynamic!";
		
		$data['menu'] = $this->get_menu();

		$this->load->view('testview', $data);
	}

	function get_menu() {
		$this->load->library('menu');
		$mymenu = $this->menu->show_menu();
		return $mymenu;
	}
}
