<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Code Igniter
 *
 * An open source application development framework for PHP 4.3.2 or newer
 *
 * @package		CodeIgniter
 * @author		Hirotoshi Shibayama
 * @copyright	Copyright (c) 2010, C.A.MOBILE, Inc.
 * @license		
 * @link		
 * @since		Version 1.0
 * @filesource
 */
 
// ------------------------------------------------------------------------

/**
 * Code Array Convert Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		Hirotoshi Shibayama
 * @link		
 */

// ------------------------------------------------------------------------

/**
 * 配列の各データに対し、再起的にデータを確認し、
 * 数字の文字列である場合は、Int型に変更
 * 
 * @param array $array 配列(複数次元OK)
 */
function convertArrayStr2Int($array){
	array_walk_recursive($array, '_numStrToInt');
	return $array;	
}

/**
 * 
 * 数字の文字列をInt型に変換する
 * @param string $value
 * @param unknown_type $key
 */	
function _numStrToInt(&$value, $key) {
	// コンバート除外配列
	$exclusionArray = array('uniqueId','name','sendUserName','postUserName','clerkUserName','message','questMemo');
	
	// 除外データを除き、データが数値であればintにする
	if(ctype_digit($value) && is_string($value) && !in_array($key, $exclusionArray)) {
		$value = (int) $value;
  	}
}
?>