<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Code Igniter
 *
 * An open source application development framework for PHP 4.3.2 or newer
 *
 * @package		CodeIgniter
 * @author		Hirotoshi Shibayama
 * @copyright	Copyright (c) 2010, C.A.MOBILE, Inc.
 * @license		
 * @link		
 * @since		Version 1.0
 * @filesource
 */
 
// ------------------------------------------------------------------------

/**
 * Friend Max Check Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		Hirotoshi Shibayama
 * @link		
 */

// ------------------------------------------------------------------------

/**
 * 友達数がMAX値に達しているかの確認
 * @param string $userId ユーザID
 * @param int $add この値の分、猶予とする
 * @return boolean MAX値に達していればtrue,そうでなければfalse
 */
function friendMaxCheck($userId, $add = 0){
	// コントローラインスタンス取得
	$CI =& get_instance();
	
	// Player_Statusモデルをロード
	$CI->load->model('Player_Status', '', TRUE);
	$playerLevel = $CI->Player_Status->get_player_level($userId);
	
	// Player_Friendモデルをロード
	$CI->load->model('Player_Friend', '', TRUE);
	$playerFriendCount = $CI->Player_Friend->get_player_friend_count($userId);
	
	// Player_Feedモデルをロード
	$CI->load->model('Player_Feed', '', TRUE);
	$playerFriendRequestCount = $CI->Player_Feed->get_friend_request_count($userId);
	
	// 合計する
	$totalCount = $playerFriendCount + $playerFriendRequestCount;
	
	// それぞれのしきい値のレベルに達しているかに合わせてチェック
	switch ($playerLevel){
		case $playerLevel < 4:
			return ($totalCount >= 10);
			break;
		case $playerLevel < 8:
			return ($totalCount >= 15);
			break;
		case $playerLevel < 15:
			return ($totalCount >= 20);
			break;
		case $playerLevel < 25:
			return ($totalCount >= 22);
			break;
		case $playerLevel < 35:
			return ($totalCount >= 24);
			break;
		case $playerLevel < 45:
			return ($totalCount >= 26);
			break;
		case $playerLevel < 60:
			return ($totalCount >= 28);
			break;
		case $playerLevel < 80:
			return ($totalCount >= 30);
			break;
		case $playerLevel < 100:
			return ($totalCount >= 32);
			break;
		default:
			return ($totalCount >= 34);	
			break;
	}
}

/**
 * 友達リクエストに関する状況確認
 * @param string $userId ユーザID
 * @param string $friendId 友達のユーザID
 * @return int 1:すでに友達 2:どちらかがリクエスト済み 3:友達リクエスト制限数に達している 4:問題なし
 */
function isRequestCheck($userId, $friendId){
	// コントローラインスタンス取得
	$CI =& get_instance();
	
	// Player_Friendモデルをロード
	$CI->load->model('Player_Friend', '', TRUE);
	
	// すでに友達であるかをチェック
	$isFriend = $CI->Player_Friend->get_player_friend_exist($userId, $friendId);
	if($isFriend){
		return 1;
	}
	
	// Player_Feedモデルをロード
	$CI->load->model('Player_Feed', '', TRUE);
	// 既にリクエスト済み
	$isRequested = $CI->Player_Feed->get_friend_requested($userId, $friendId);
	if($isRequested){
		return 2;
	}
	
	// 友達数がMAX値に達しているかの確認
	if(friendMaxCheck($userId)){
		return 3;
	}
	
	// 相手が友達数がMAX値に達しているかの確認
	if(friendMaxCheck($friendId)){
		return 4;
	}
	
	return 5;
}
?>