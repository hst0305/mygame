<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Code Igniter
 *
 * An open source application development framework for PHP 4.3.2 or newer
 *
 * @package		CodeIgniter
 * @author		Hirotoshi Shibayama
 * @copyright	Copyright (c) 2010, C.A.MOBILE, Inc.
 * @license		
 * @link		
 * @since		Version 1.0
 * @filesource
 */
 
// ------------------------------------------------------------------------

/**
 * Header Check Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		Hirotoshi Shibayama
 * @link		
 */

// ------------------------------------------------------------------------

/**
 * ヘッダーのハッシュと、計算したハッシュが同一であるかの確認
 * @return boolean 一致していればtrue,そうでなければfalse
 */
function headerCheck(){
	// コントローラインスタンス取得
	$CI =& get_instance();
	$CI->load->helper('json_multi');
	$CI->load->helper('array_convert');
	
	// ヘッダー値
	$headerParam = $CI->input->get_request_header('X-deli');
	
	// hash計算(POSTの数字をintに変更し、JSON化したもののBase64にし(マルチバイト対応のため)、その値のhashを取得)	
	$hash = sha1(base64_encode(json_encode_multi(convertArrayStr2Int($_POST))));
	
	// 同一かどうかを確認
	if($headerParam == $hash){
		return true;
	} else {
		log_message('error', 'Invalid header :: '. $_SERVER{'REQUEST_URI'} .' :: param:' . serialize($_POST));
		return false;
	}
}
?>