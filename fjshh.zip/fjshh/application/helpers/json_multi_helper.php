<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Code Igniter
 *
 * An open source application development framework for PHP 4.3.2 or newer
 *
 * @package		CodeIgniter
 * @author		Rick Ellis
 * @copyright	Copyright (c) 2006, pMachine, Inc.
 * @license		http://www.codeignitor.com/user_guide/license.html 
 * @link		http://www.codeigniter.com
 * @since		Version 1.0
 * @filesource
 */
 
// ------------------------------------------------------------------------

/**
 * Code Igniter JSON 4 Multi Byte Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		Hitotoshi shibayama
 * @link		
 */

// ------------------------------------------------------------------------


/* Loading the helper automatically requires and instantiates the Services_JSON class */
if ( ! class_exists('Services_JSON_Multi'))
{
  	require_once(APPPATH.'helpers/JSON_Multi.php');
}

/**
 * json_encode_multi
 *
 * 全角文字をそのままにするJSONエンコード
 *
 * @access	public
 * @param	string
 * @return	string
 */
function json_encode_multi($data = null)
{
  	if($data == null) return false;
	$json = new Services_JSON_Multi();
  	return $json->encode($data);
}
?>