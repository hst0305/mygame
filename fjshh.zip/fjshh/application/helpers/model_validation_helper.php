<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Code Igniter
 *
 * An open source application development framework for PHP 4.3.2 or newer
 *
 * @package		CodeIgniter
 * @author		Hirotoshi Shibayama
 * @copyright	Copyright (c) 2010, C.A.MOBILE, Inc.
 * @license		
 * @link		
 * @since		Version 1.0
 * @filesource
 */
 
// ------------------------------------------------------------------------

/**
 * Code Validation in Model Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		Hirotoshi Shibayama
 * @link		
 */

// ------------------------------------------------------------------------

/**
 * 配列の各データに対し、再起的にデータを確認し、
 * Validationを行う
 * 
 * @param array $array 配列(複数次元OK)
 * @param array $itemList 各データのバリデーションルール
 * @return boolean 問題がなければtrue、問題があればfalse
 */
function modelCheckData($data, $itemList){
	foreach($itemList as $key => $val){
		// key自体は存在することを必須とする
		if(!array_key_exists($key, $data)){
			log_message('error', 'Parameter ['. $key . '] is not setting.');			
			return false;
		}
		
		// 配列の場合はそれぞれのデータについて再度チェック
		if(is_array($val)){
			$validate = modelCheckData($data[$key], $val);
			if(!$validate){
				// ログ記述済み
				return false;
			}
		// 配列以外の場合
		} else {
			// バリデーション結果の初期化
			$validate = null;
			
			// データを[,]で分割、最初が型,2つ目が必須チェック
			$val_decode = explode('|', $val);
			// データ型の決定
			$type = $val_decode[0];
			// 配列が2つの時のみ,必須チェックの要否を確認する
			if(count($val_decode) == 2){
				// 値がfalseならば必須チェック除外
				if($val_decode[1] == 'false'){
					$require = false;
				} else {
					$require = true;
				}
			// それ以外はデフォルトでtrue
			} else {
				$require = true;
			}
			
			// 必須チェックをしない場合、そのkeyのデータがnull,空文字は正常扱いで終了
			if(!$require){
				if(is_null($data[$key]) || $data[$key] === "")
				$validate = true;
			}
			
			// バリデーション結果が決定していない場合
			if(!$validate){
				switch ($type){
					case 'int':
						$validate = is_int($data[$key]);
						break;
					case 'float':
						$validate = is_numeric($data[$key]);
						break;
					case 'string':
						$validate = is_string($data[$key]);
						break;
					case 'boolean':
						$validate = is_bool($data[$key]);
						break;
					case 'timestamp':
						// 空文字はtrueとする
						if($data[$key] == ''){
							$validate = true;
						} else {
							$validate = (is_int($data[$key]) && 0 <= $data[$key] && $data[$key] <= 2147483647);
						}
						break;
					case 'date':
						// 空文字はtrueとする
						if($data[$key] == ''){
							$validate = true;
						} else {
							$validate = (bool)preg_match("|^\d{4}-\d{2}-\d{2}$|", $data[$key]);
						}
						break;
					case 'datetime':
						// 空文字はtrueとする
						if($data[$key] == ''){
							$validate = true;
						} else {
							$validate = (bool)preg_match("|^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$|", $data[$key]);
						}
						break;
				}
			}
			
			if(!$validate){
				log_message('error', 'Parameter ['. $key . '] is not "'. $type . '".');
				return false;
			}
		}
	}
	return true;
}
?>