<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Code Igniter
 *
 * An open source application development framework for PHP 4.3.2 or newer
 *
 * @package		CodeIgniter
 * @author		Hirotoshi Shibayama
 * @copyright	Copyright (c) 2010, C.A.MOBILE, Inc.
 * @license		
 * @link		
 * @since		Version 1.0
 * @filesource
 */
 
// ------------------------------------------------------------------------

/**
 * Code Igniter OAuth Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		Hirotoshi Shibayama
 * @link		
 */

// ------------------------------------------------------------------------

// OAuthモジュール読み込み
require_once(APPPATH.'helpers/OAuth.php');

/**
 * Bank用 TranzactionId発行にてJSON指定するパラメータのチェック
 * @param array 送信配列
 * @return mixed 正しい場合はJSON文字列、間違っている場合はfalse
 */
function jsonBankFormatCheck4Transaction($param){
	return jsonBankFormatCheck($param, OAuthConfig::BANK_TRANSACTION);
}

/**
 * Bank用 UpdateにてJSON指定するパラメータのチェック
 * @param array 送信配列
 * @return mixed 正しい場合はJSON文字列、間違っている場合はfalse
 */
function jsonBankFormatCheck4Update($param){
	return jsonBankFormatCheck($param, OAuthConfig::BANK_UPDATE);
}

/**
 * bank各通信にてJSON指定するパラメータのチェック
 * @param array 送信配列
 * @param int $accessFragmentType アクセスするフラグメント
 * @return mixed 正しい場合はJSON文字列、間違っている場合はfalse
 */
function jsonBankFormatCheck($param, $accessFragmentType){
	// パラメータがない場合はエラー
	if(!$param){
		return false;
	}

	switch ($accessFragmentType){
		// BANK API(Transaction)
		case OAuthConfig::BANK_TRANSACTION:
			$checkArray = array('items', 'comment', 'state');
			break;
		// BANK API(Update)
		case OAuthConfig::BANK_UPDATE:
			$checkArray = array('state');
			break;
		default:
			return false;
	}
	
	// 要素が規定数以外はfalse
	if(count($param) != count($checkArray)){
		return false;
	}
	
	// 各要素のチェック
	foreach($checkArray as $val){
		// チェック対象にはいってなければエラー
		if(!array_key_exists($val, $param)){
			return false;
		}
		
		// チェックするkeyに合わせて確認
		switch($val){
			case 'id':
				if(!is_string($param[$val])){
					return false;
				}
				continue;
			case 'items':
				//itemsの中身は検証しない
				// 要素が2つ以外はfalse
//				if(count($param[$val]) != 2){
//					return false;
//				}
//				foreach($param[$val] as $sub_key => $sub_val){
//					// 子要素のチェック
//					switch($sub_key){
//						case 'item':
//							if(!is_array($sub_val)){
//								return false;
//							}
//							continue;
//						case 'quantity':
//							if(!is_int($sub_val)){
//								return false;
//							}
//							continue;
//						// その他のkeyがある場合はその時点で終了
//						default :
//							return false;
//					}
//				}
				continue;
			case 'comment':
				if(!is_string($param[$val])){
					return false;
				}
				continue;
			case 'state':
				if(!in_array($param[$val], array('new', 'open', 'closed'))){
					return false;
				}
				continue;
			case 'published':
			case 'updated':
				if(!preg_match('/\d{4}\-\d{2}\-\d{2}T\d{2}:\d{2}:\d{2}/', $param[$val])){
					return false;
				}
				continue;
			// 規定以外の値が存在する場合はその時点でエラー
			default:
				return false;
		}
	}
	
	// JSON化した文字列を返す
	return json_encode_multi($param);
}

/**
 * TemporaryCredencialの取得
 * @return mixed 取得結果
 */
function getOAuthTemporaryCredential(){
	return OAuthGetByCUrl(OAuthConfig::AUTH_TEMPORARY_CREDENTIAL, null, '', false);
}

/**
 * TokenCredencialの取得
 * @return mixed 取得結果
 */
function getOAuthTokenCredential($verifier){
	return OAuthGetByCUrl(OAuthConfig::AUTH_TOKEN_CREDENTIAL, $verifier);
}

/**
 * GAME API(People)にて自分自身の情報を取得
 * @return mixed 取得結果
 */
function getRestfulPeopleOfMine(){
	// 追加パラメータ設定
	$addParam = array(
					'param'	 => array('@me', '@self'),
					'fields' => array('id','displayName','thumbnailUrl')
					);
	return OAuthGetByCUrl(OAuthConfig::GAME_PEOPLE, $addParam);
}

/**
 * BANKにてトランザクションを新規生成
 * @param string $postJson リクエストに渡すJSON文字列
 * @return mixed 取得結果
 */
function getRestfulBankDebitTransaction($postJson){
	// 追加パラメータ設定
	$addParam = array(
					'param'	 => array('@app'),
					);
	return OAuthGetByCUrl(OAuthConfig::BANK_TRANSACTION, $addParam, $postJson);
}

/**
 * BANKにてトランザクションの更新処理(確認&完了)
 * @param string $postJson リクエストに渡すJSON文字列
 * @param string $transactionId トランザクションID
 * @return mixed 取得結果
 */
function getRestfulBankDebitUpdate($postJson, $transactionId){
	// 追加パラメータ設定
	$addParam = array(
					'param'	 => array('@app',$transactionId),
					'fields' => array('state')
					);
	return OAuthGetByCUrl(OAuthConfig::BANK_UPDATE, $addParam, $postJson);
}

/**
 * BANKにてトランザクションの更新処理(Batch用)
 * @param string $postJson リクエストに渡すJSON文字列
 * @param string $transactionId トランザクションID
 * @param array $dbData DBデータ
 * @return mixed 取得結果
 */
function getRestfulBankDebitUpdate4Batch($postJson, $transactionId, $dbData){
	// 追加パラメータ設定
	$addParam = array(
					'param'	 => array('@app',$transactionId),
					'fields' => array('state')
					);
	return OAuthGetByCUrl(OAuthConfig::BANK_UPDATE, $addParam, $postJson, true, $dbData);
}

/**
 * BANKにてトランザクションのデータ確認
 * @param string $transactionId トランザクションID
 * @return mixed 取得結果
 */
function getRestfulBankDebitGetData($transactionId){
	// 追加パラメータ設定
	$addParam = array(
					'param'	 => array('@app',$transactionId)
					);
	return OAuthGetByCUrl(OAuthConfig::BANK_GET, $addParam);
}

/**
 * BANKにてトランザクションのデータ確認(Batch用)
 * @param string $transactionId トランザクションID
 * @param array $dbData DBデータ
 * @return mixed 取得結果
 */
function getRestfulBankDebitGetData4Batch($transactionId, $dbData){
	// 追加パラメータ設定
	$addParam = array(
					'param'	 => array('@app',$transactionId)
					);
	return OAuthGetByCUrl(OAuthConfig::BANK_GET, $addParam, '', true, $dbData);
}

/**
 * OAuthにCURLを使って接続
 * @param int $accessFragmentType アクセスするフラグメント
 * @param mixed $addParam 追加パラメータ(string or array or null)
 * @param string $postJson POSTするJSON文字列(デフォルト:空文字)
 * @param boolean $makeToken 事前にセッションにあるtokenデータを元にtokenを作成するか(デフォルト:true)
 * @param array $dbData DBデータ Batchの時のみ使用(デフォルトnull)
 * @return mixed 取得結果
 */
function OAuthGetByCUrl($accessFragmentType, $addParam = '', $postJson = '', $makeToken = true, $dbData = null){
	// MobageAPIのインスタンス化
	$mobageApi = new OAuthMobageApi($accessFragmentType, $addParam, $makeToken, $dbData);
	
	// MobageAPIへのリクエスト結果を返す
	$objReturn = $mobageApi->sendRequest($postJson);
	
	return $objReturn;
}

// MobageAPIによるデータ取得
class OAuthMobageAPI{
	
	var $_accessFragmentType;
	
	var $_consumer;
	var $_token;
	var $_oauth2_token;
	var $_method;
	var $_url;
	var $_addHeaderParam;
	
	/**
	 * コンストラクタ
	 * @param int $accessFragmentType アクセスするフラグメント
	 * @param mixed $param 追加パラメータ(string or array or null)
	 * @param boolean $makeToken 事前にセッションにあるtokenデータを元にtokenを作成するか(デフォルト:true)
	 * @param array $dbData DBデータ Batchの時のみ使用(デフォルトnull)
	 */
	public function __construct($accessFragmentType, $param, $makeToken = true, $dbData = null){
		
		// アクセスするフラグメントをクラス変数に保存
		$this->_accessFragmentType = $accessFragmentType;
		
		// $addParamが配列の場合はパラメータ扱いとし、verifierはnullとする
		if(is_array($param)){
			$addParam = $param;
			$verifier = null;
		// それ以外はverifierとして扱い、パラメータはなしとする
		} else {
			$addParam = null;
			$verifier = $param;
		}
		
		// Configのインスタンス化
		$config = new OAuthConfig($accessFragmentType, $addParam, $verifier, $dbData);
	
		// KEYの作成
		$this->_consumer = $config->getConsumer();
		
		if($makeToken){
			$this->_token = $config->getToken($dbData);
		} else {
			$this->_token = false;
		}
		
		// 通信Methodの取得
		$this->_method = $config->getMethod();
		
		// URLの取得
		$this->_url = $config->getRequestUrl();
		
		// ヘッダに追加するパラメータの設定
		$this->_addHeaderParam = $config->getAdditionalHeaderParam();
		
		// oauth2_tokenの取得
		$this->_oauth2_token = $config->getOauth2Token();
	}
	
	/**
	 * リクエストを行う
	 * @param string $postJson JSON文字列(デフォルト文字)
	 */
	public function sendRequest($postJson = ''){
		// リクエストクラスにてリクエストを作成
		$request = OAuthRequest::from_consumer_and_token($this->_consumer, $this->_token, $this->_method, $this->_url, $this->_addHeaderParam);
		$request->sign_request(new OAuthSignatureMethod_HMAC_SHA1(), $this->_consumer, $this->_token);
		
		// ヘッダーの作成
		$auth_header = $request->to_header();
		
		// CURLにてアクセスする
		$curl = curl_init($this->_url);
		
		// oauth2_tokenがある場合、auth_headerを変更
		if($this->_oauth2_token != ''){
			$header_array = array($this->_oauth2_token, 'Accept: */*', 'Content-Type:application/json;charset=utf-8','Content-length:'.strlen($postJson));
		} else {
			$header_array = array($auth_header, 'Content-Type:application/json;charset=utf-8','Content-length:'.strlen($postJson));
		}
		
		// OPTION設定
		$curlSetOption = array(
								CURLOPT_HTTPHEADER		=> $header_array,
								CURLOPT_HTTPAUTH		=> CURLAUTH_BASIC,
								CURLOPT_SSLVERSION		=> 3,
								CURLINFO_HEADER_OUT		=> TRUE,
								CURLOPT_SSL_VERIFYPEER	=> FALSE,
								CURLOPT_SSL_VERIFYHOST	=> FALSE,
								CURLOPT_RETURNTRANSFER	=> TRUE,
								CURLOPT_FAILONERROR		=> FALSE,
								);
		
		// POSTの場合
		if($this->_method == 'POST'){
			$curlSetOption[CURLOPT_POST] = 1;
			$curlSetOption[CURLOPT_POSTFIELDS] = $postJson;
		}
		
		// PUTの場合
		if($this->_method == 'PUT'){
			$curlSetOption[CURLOPT_CUSTOMREQUEST] = 'PUT';
			$curlSetOption[CURLOPT_POST] = 1;
			$curlSetOption[CURLOPT_POSTFIELDS] = $postJson;
		}
								
		curl_setopt_array($curl, $curlSetOption);
		
		// レスポンスとステータスの取得
		$response = curl_exec($curl);
		
		$status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
		
//		error_log($postJson);
//		error_log(serialize(curl_getinfo($curl)));
//		error_log($status);
//		error_log($response);
		curl_close($curl);
		// ステータスが200,201,202以外はfalseとする
		if(!in_array($status, array(200, 201, 202))){
			log_message('error', 'Social error [Code : '. $status . ' ]');
			return array('result' => false, 'message' => $response);
		} else {
			// フラグメントに合わせてデータをコンバート
			switch ($this->_accessFragmentType){
				// temporary_credential(AUTH)
				case OAuthConfig::AUTH_TEMPORARY_CREDENTIAL:
				// token_credential(AUTH)
				case OAuthConfig::AUTH_TOKEN_CREDENTIAL:
					$returnObj = $this->_decodeOAuthResponse($response);
					break;
				// GAME API(People)
				case OAuthConfig::GAME_PEOPLE:
				// BANK API(transaction)
				case OAuthConfig::BANK_TRANSACTION:
				// BANK API(Update)
				case OAuthConfig::BANK_UPDATE:
				// BANK API(Get)
				case OAuthConfig::BANK_GET:
					$returnObj = json_decode($response, true);
					break;
			}
			
			
			return array('result' => true, 'message'=> '', 'object' => $returnObj);
		}
	}
	
	/**
	 * CURLのレスポンスを変換する
	 * @param string $response CURLによるレスポンス文字列
	 * @return array 変換結果
	 */
	private function _decodeOAuthResponse($response){
		
		$return = array();
		$param = explode('&', urldecode($response));
		
		foreach($param as $val){
			$position = mb_strpos($val, '=');
			$key = mb_substr($val, 0, $position);
			$body = mb_substr($val, $position+1);
			$return[$key] = $body;
			if($key == 'oauth_token'){
				$subPosition = mb_strpos($body, ':');
				$subKey = mb_substr($body, 0, $subPosition);
				$subBody = mb_substr($body, $subPosition+1);
				$return[$subKey] = $subBody;
			}
		}
		return $return;
	}
}

/**
 * OAuth設定クラス
 * @author shibayama
 */
class OAuthConfig{
	
	var $_CI;
	var $_locateId;
	var $_oauth2_token;
	var $_accessFragmentType;
	var $_verifier;
	var $_addParam;
	
	var $_customer_key;
	var $_customer_secret_key;
	var $_url;
	
	// AUTH (接続時処理)
	const AUTH_TEMPORARY_CREDENTIAL = 11;
	const AUTH_TOKEN_CREDENTIAL 	= 12;
	
	// GAME API
	const GAME_PEOPLE				= 21;
	
	// BANK API
	const BANK_TRANSACTION			= 31;
	const BANK_UPDATE				= 32;
	const BANK_GET					= 33;
	
	/**
	 * コンストラクタ
	 * @param int $accessFragmentType アクセスするフラグメント
	 * @param array $addParam 追加パラメータ(array or null)
	 * @param string $verifier verifier(TokenCredentialに使用)
	 * @param array $dbData DBデータ Batchの時のみ使用(デフォルトnull)
	 */
	public function __construct($accessFragmentType, $addParam, $verifier, $dbData = null){
		// コントローラインスタンス取得
		$this->_CI =& get_instance();
		
		// DBデータ指定のある場合
		if($dbData){
			//引数のデータよりlocateIdを取得
			$this->_locateId = (int)$dbData['locateId'];
			// oauth2_tokenは空とする
//			$this->_oauth2_token = $dbData['oauth2Token'];
			$this->_oauth2_token = '';
		} else {
			// セッションよりlocateIdを取得
			$this->_locateId = $this->_CI->session->userdata('locateId');
			// USでトランザクション作成、更新の場合はoauth_tokenを設定する
			if($this->_locateId == LOCATE_ID_US && in_array($accessFragmentType, array(self::BANK_TRANSACTION, self::BANK_UPDATE))){
				$this->_oauth2_token = 'Authorization: bearer '. $this->_CI->session->userdata('oauth2_token');
			// それ以外はoauth2_tokenは空とする
			} else {
				$this->_oauth2_token = '';
			}
		}
		
		// アクセスするフラグメントをクラス変数に保存
		$this->_accessFragmentType = $accessFragmentType;
		
		// パラメータの設定
		$this->_addParam = $this->_makeParamToUrl($addParam);
		
		// verifierの設定
		$this->_verifier = $verifier;
		
	}
	
	/**
	 * oauth2_tokenの取得
	 * @return string oauth2_token
	 */
	function getOauth2Token(){
		return $this->_oauth2_token;
	}
	
	/**
	 * URLに付与するパラメータを文字列に変更する
	 * @param array $addParam 追加パラメータ(array or null)
	 * @return string 配列をベースに文字列化したもの
	 */
	private function _makeParamToUrl($addParam){
		// パラメータが配列でない場合は空文字を返す
		if(!is_array($addParam)){
			return '';
		}
		
		// 文字列の初期化
		$strUrl = '';
		// パラメータを連結
		foreach($addParam['param'] as $param){
			$strUrl .= '/' . $param;
		}
		
		// fields指定がある場合
		if(array_key_exists('fields', $addParam)){
			$strUrl .= '?fields=';
			
			foreach($addParam['fields'] as $fields){
				$strUrl .= $fields . ',';
			}
			// 最後の[,]を削る
			$strUrl = substr($strUrl, 0, -1);
		}
		
		return $strUrl;
	}
	
	/**
	 * OAuthConsumerオブジェクトの取得
	 * @return object OAuthToken
	 */
	public function getConsumer(){
		return new OAuthConsumer($this->_getCustomerKey(), $this->_getCustomerSecretKey());
	}
	
	/**
	 * CUSTOMER_KEYの取得
	 * @return string CUSTOMER_KEY
	 */
	private function _getCustomerKey(){
		$customerKeyTmp = $this->_CI->config->item('customer_key');
		return $customerKeyTmp[$this->_locateId];
	}
	
	/**
	 * CUSTOMER_SECRET_KEYの取得
	 * @return string CUSTOMER_SECRET_KEY
	 */
	private function _getCustomerSecretKey(){
		$customerSecretKeyTmp = $this->_CI->config->item('customer_secret_key');
		return $customerSecretKeyTmp[$this->_locateId];
	}
	
	/**
	 * セッションからトークンパラメータを生成
	 * @param array $dbData DBデータ Batchの時のみ使用(デフォルトnull)
	 * @return object OAuthToken
	 */
	public function getToken($dbData = null){
		// DBデータ指定のある場合
		if($dbData){
			// トークンを引数のデータから取得
			$key = $dbData['oauthToken'];
			$secret = $dbData['oauthTokenSecret'];
		} else {
			// セッションライブラリをロードする
			$this->_CI->load->library('session');
			
			// トークンをセッションから取得
			$key = $this->_CI->session->userdata('oauth_token');
			$secret = $this->_CI->session->userdata('oauth_token_secret');
		}
		return new OAuthToken($key, $secret);
	}
	
	/**
	 * METHODの取得
	 * @return string GET,POST,PUT,DELETEのいずれか
	 */
	public function getMethod(){
		switch ($this->_accessFragmentType){
			// temporary_credential(AUTH)
			// token_credential(AUTH)
			case self::AUTH_TEMPORARY_CREDENTIAL:
			case self::AUTH_TOKEN_CREDENTIAL:
				return 'POST';
			// GAME API(People)
			case self::GAME_PEOPLE:
				return 'GET';
			// BANK API(Transaction)
			case self::BANK_TRANSACTION:
				return 'POST';
			// Bank API(Update)
			case self::BANK_UPDATE:
				return 'PUT';
			// Bank API(Get)
			case self::BANK_GET:
				return 'GET';
		}
	}
	
	/**
	 * リクエストするURLの取得
	 * @return string リクエストするURL
	 */
	public function getRequestUrl(){
		switch ($this->_accessFragmentType){
			// temporary_credential(AUTH)
			case self::AUTH_TEMPORARY_CREDENTIAL:
				return $this->_getAuthUrl().'/request_temporary_credential';
			// token_credential(AUTH)
			case self::AUTH_TOKEN_CREDENTIAL:
				return $this->_getAuthUrl().'/request_token';
			// GAME API(People)
			case self::GAME_PEOPLE:
				return $this->_getSocialUrl().'/people'.$this->_addParam;
			// Bank API(Transaction)
			case self::BANK_TRANSACTION:
			// Bank API(Update)
			case self::BANK_UPDATE:
			// Bank API(Get)
			case self::BANK_GET:
				return $this->_getBankUrl().'/bank/debit'.$this->_addParam;
		}
	}
	
	/**
	 * AUTH_URLの取得
	 * @return string AUTH_URLの共通部分
	 */
	private function _getAuthUrl(){
		$authUrlTmp = $this->_CI->config->item('rest_api_auth_url');
		return $authUrlTmp[$this->_locateId];
	}
	
	/**
	 * SOCIAL_URLの取得
	 * @return string SOCIAL_URLの共通部分
	 */
	private function _getSocialUrl(){
		$socialUrlTmp = $this->_CI->config->item('rest_api_social_url');
		return $socialUrlTmp[$this->_locateId];
	}
	
	/**
	 * BANK_URLの取得
	 * @return string BANK_URLの共通部分
	 */
	private function _getBankUrl(){
		$bankUrlTmp = $this->_CI->config->item('rest_api_bank_url');
		return $bankUrlTmp[$this->_locateId];
	}
	
	/**
	 * リクエストヘッダに追加するパラメータ
	 * @return mixed AUTHアクセスは配列、それ以外はNULL
	 */
	public function getAdditionalHeaderParam(){
		switch ($this->_accessFragmentType){
			// temporary_credential(AUTH)
			case self::AUTH_TEMPORARY_CREDENTIAL:
				return array('oauth_callback' => "oob");
			// token_credential(AUTH)
			case self::AUTH_TOKEN_CREDENTIAL:
				// 事前設定済みのverifierを使用
				return array('oauth_verifier' => $this->_verifier);
			default:
				return NULL;
		}
	}
}
?>