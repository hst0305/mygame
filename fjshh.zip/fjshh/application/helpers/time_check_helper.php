<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Code Igniter
 *
 * An open source application development framework for PHP 4.3.2 or newer
 *
 * @package		CodeIgniter
 * @author		Hirotoshi Shibayama
 * @copyright	Copyright (c) 2010, C.A.MOBILE, Inc.
 * @license		
 * @link		
 * @since		Version 1.0
 * @filesource
 */
 
// ------------------------------------------------------------------------

/**
 * Time Check Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		Hirotoshi Shibayama
 * @link		
 */

// ------------------------------------------------------------------------

/**
 * 時間のチェックを行う
 * @param $userId ユーザーID(ログ送出用)
 * @param $isSync 更新作業か(デフォルトfalse)
 * @return boolean 規定の範囲外であればtrue,範囲内であればfalse
 */
function timeCheck($userId, $isSync=false){
	// iosの場合はチェックをしない
	if(preg_match('/ngcore\-ios/', $_SERVER['HTTP_USER_AGENT']) == 1){
		return false;
	}
	
	// コントローラインスタンス取得
	$CI =& get_instance();
	
	// クライアントのタイムスタンプ
	$localTime = $CI->input->post('lt');
	
	// サーバー時間
	$serverTime = time();
	
	// 差が規定値以内であればfalseを返す
	if(abs($serverTime - $localTime) <= LOCAL_TIME_LAG_LIMIT){
		return false;
	} else {
		// 更新時は901エラー、それ以外は900エラー
		if($isSync){
			log_message('error', '901:LocalTime Error :: userId='.$userId);
		} else {
			log_message('error', '900:LocalTime Error :: userId='.$userId);
		}
		return true;
	}
}
?>