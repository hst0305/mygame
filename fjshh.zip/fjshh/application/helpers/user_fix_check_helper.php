<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Code Igniter
 *
 * An open source application development framework for PHP 4.3.2 or newer
 *
 * @package		CodeIgniter
 * @author		Hirotoshi Shibayama
 * @copyright	Copyright (c) 2010, C.A.MOBILE, Inc.
 * @license		
 * @link		
 * @since		Version 1.0
 * @filesource
 */
 
// ------------------------------------------------------------------------

/**
 * Users on Fix Check Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		Hirotoshi Shibayama
 * @link		
 */

// ------------------------------------------------------------------------

/**
 * メンテナンス中かの確認
 * @param int $userId ユーザID
 * @return boolean メンテナンス中であればtrue,そうでなければfalse
 */
function userOnfix($userId){
	// コントローラインスタンス取得
	$CI =& get_instance();
	
	// User_On_Fixモデルをロード
	$CI->load->model('User_On_Fix', '', TRUE);
	$isFixed = $CI->User_On_Fix->is_fixed($userId);
	
	// 結果をそのまま返す
	return $isFixed;
}
?>