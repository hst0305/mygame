<?php
class Menu{
	function show_menu()
	{
		$obj =& get_instance();
		$obj->load->helper('url');
		$menu = anchor("start/hello/zhisu","Say hello to zhisu | ");
		$menu .= anchor("start/hello/lvlin","Say hello to lvlin | ");
		$menu .= anchor("start/another_function","Do something else |");
		return $menu;
	}
 }
?>