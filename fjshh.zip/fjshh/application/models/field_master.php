<?php 
/**
 * Field_Master模型
 * 
 * @author lvlin
 */
class Field_Master extends CI_Model {

	var $table_name		= 'FieldMaster';
	
	/**
	 * コンストラクタ
	 */
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	/**
	 * 取得FieldMaster表中的前五列数据
	 *
	 */
	function get_field_master_top5()
	{
			$query = $this->db->from($this->table_name)
							  ->limit(5)
							  ->get();
			
			
			if ($query->num_rows() > 0){
				$result = $query->result_array();
				return $result;
			} else {
				return false;
			}
	}

}