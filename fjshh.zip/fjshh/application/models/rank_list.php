<?php 
/**
 * Rank_List模型
 * 
 * @author lvlin
 */
class Rank_List extends CI_Model {

	var $table_name	= 'RankList';
	
	/**
	 * コンストラクタ
	 */
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	/**
	 * 取得RankList表中的所有数据
	 *
	 */
	function get_rank_list()
	{
			$query = $this->db->select('count,seconds')
						->from($this->table_name)
						->order_by("count", "desc")
				 		->order_by("seconds", "asc")
						->get();
			if ($query->num_rows() > 0){
				$row = $query->result_array();
				return $row;
			} else {
				return false;
			}
	}

	function insert_rank($newRank)
	{
		$now = date("Y-m-d H:i:s");
		$newRank['createAt'] = $now;
			
		$this->db->insert($this->table_name, $newRank);
			
		if ($this->db->trans_status() === FALSE) {
			return false;
		}

		return true;
	}

}