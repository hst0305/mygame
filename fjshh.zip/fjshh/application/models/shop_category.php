<?php 
/**
 * Shop_Category模型
 * 
 * @author lvlin
 */
class Shop_Category extends CI_Model {

	var $table_name		= 'fjshh_category';
	
	/**
	 * コンストラクタ
	 */
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	
	function get_name_by_id($category_id)
	{
		$query = $this->db->from($this->table_name)
		->where('id',$category_id)
		->get();
	
		
			if ($query->num_rows() > 0){
				$row = $query->row_array();
				return $row;
			} else {
				return false;
			}
	}

}