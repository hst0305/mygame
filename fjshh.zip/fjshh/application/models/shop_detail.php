<?php 
/**
 * Shop_Detail模型
 * 
 * @author lvlin
 */
class Shop_Detail extends CI_Model {

	var $table_name		= 'fjshh_shop_detail';
	
	/**
	 * コンストラクタ
	 */
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	/**
	 * 根据id商家获取详细资料
	 *
	 */
	function get_shop_detail($detail_id)
	{
			$query = $this->db->from($this->table_name)
							->where('id', $detail_id)
							  ->get();
			
			
			if ($query->num_rows() > 0){
				$row = $query->row_array();
				return $row;
			} else {
				return false;
			}
	}

}