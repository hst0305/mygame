<?php 
/**
 * Shop_Detail模型
 * 
 * @author lvlin
 */
class Shop_List extends CI_Model {

	var $table_name		= 'fjshh_shop_list';
	
	/**
	 * コンストラクタ
	 */
	function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	/**
	 * 根据分类id获取商家列表
	 *
	 */
	function get_shop_list($type)
	{
			$query = $this->db->select('detail_id','name')
										->where('type', $type)
										->from($this->table_name)
										->join('fjshh_category', 'fjshh_shop_list.category_id = fjshh_category.id')
							  			->get();
			
				
			if ($query->num_rows() > 0){
				$result = $query->result_array();
				return $result;
			} else {
				return false;
			}
	}
	
	function get_shop_list_category($category_id)
	{
		$query = $this->db->from($this->table_name)
		->where('category_id',$category_id)
		->limit(5)
		->get();
	
		if ($query->num_rows() > 0){
			$result = $query->result_array();
			return $result;
		} else {
			return false;
		}
	}
	
	function get_shop_list_more($category_id)
	{
		$query = $this->db->from($this->table_name)
		->where('category_id',$category_id)
		->get();
	
		if ($query->num_rows() > 0){
			$result = $query->result_array();
			return $result;
		} else {
			return false;
		}
	}

}