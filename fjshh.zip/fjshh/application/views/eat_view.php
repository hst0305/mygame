<!DOCTYPE html>
<html lang="zh-CN">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;">
        <meta name="format-detection" content="telephone=no">
        <title>
            	生活汇
        </title>
        <link rel="stylesheet" type="text/css" href="./misc/meishi_wei_v3.5.9.css">
        <script src="./misc/wei_webapp_v3.5.9.js">
        </script>
        <style>
            abbr,article,aside,audio,canvas,datalist,details,dialog,eventsource,figure,figcaption,footer,header,hgroup,mark,menu,meter,nav,output,progress,section,small,time,video{display:block;}
        </style>
    </head>
    <body id="" class="">
<script>
var ua = navigator.userAgent+navigator.platform;
function showBanner(){
	if(document.cookie.search('palmnews_banner=1') != -1 || ua.search('Android') == -1){
		return false;
	}
	var banner_box=document.getElementById('top_banner');
	banner_box.style.display='block';
}

function openLink(){
//	var iosdurl = '';
	var androiddurl = 'http://sina.cn/j/?k=151';
	if(ua.search('Android')!= -1){
		window.open(androiddurl);
	}
	clsBanner();
}
function clsBanner(){
    var banner_box=document.getElementById('top_banner');
    banner_box.style.display='none';
    setBannerCookie();
}
function setBannerCookie(){
	var Days = 1000;
	var exp = new Date();
	exp.setTime(exp.getTime() + Days*24*60*60*1000);
	document.cookie = "palmnews_banner=1;expires=" + exp.toGMTString()+";domain=sina.cn";
	document.cookie = "palmnews_banner=1;expires=" + exp.toGMTString()+";domain=3g.sina.com.cn";
}
showBanner();
</script>
	<!--页头信息-->
	<div class="headbox">
		<div class="logoarea">
			<h2><a href="http://sina.cn/?pos=108&vt=4" title="生活汇"></a></h2>
			<div class="navlist">
				<div class="head_nav"><!--staticdump begin--><a class="weather" href="http://weather1.sina.cn/dpool/weather_new/index.php?pos=108&vt=4"><span style="background-image:url(http://u1.sinaimg.cn/upload/cms/image/weather/h/qing.png)"></span>福州<em>-5°<code></code>-15°</em></a><!--staticdump end--></div>
			</div>
		</div>
		<div class="headnav">
			<p>
				<a href="http://sina.cn/nc.php?pos=108&vt=4" title="首页">首页</a><a href="" title="餐饮">餐饮</a><a href="http://mil.sina.cn/?pos=108&vt=4" title="娱乐">娱乐</a><a href="http://blog.sina.cn/?pos=108&vt=4" title="服务">服务</a><a href="http://sports.sina.cn/?pos=108&vt=4" title="商圈">商圈</a>
			</p>
		</div>
	</div>
	<!--推广位-->
            <div class="vs2" id="shop_lst" style="">
            <!-- 
                <article class="shoptype" id="type0">
                    <h1 style="background-image: url(http://qqfood.tc.qq.com/meishio/16/77450297-1ce0-4409-b349-79eac4440247/0); -webkit-background-size: 20px; background-size: 20px; background-position: 0px 0px; background-repeat: no-repeat no-repeat; ">
                        活动公告
                    </h1>
                    <div class="lst">
                        <ul id="lstname0">
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:55588,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5">
                                <a href="./detail.htm">
                                    走进宝龙我最闪亮 • 2013年形象大使选拔
                                </a>
                            </li>
                        </ul>
                    </div>
                </article>
                 -->
                <article class="shoptype" id="type1">
                    <h1 style="background-image: url(./misc/images/icons.png); -webkit-background-size: 15px 300px; background-size: 15px 300px; background-position: 0px 0px; background-repeat: no-repeat no-repeat; ">
                        餐饮美食
                    </h1>
                    <div class="lst">
                        <ul id="lstname1">
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50568,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5">
                                <a>
                                    2F | 马路英雄 • 8.0折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:52581,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5">
                                <a>
                                    1F | 优格花园 • 饮品5.0折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:58286,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | 便所欢乐主题餐厅 • 8.5折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:58287,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    2F | 一寿司 • 7.0折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50552,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    5F | 渔人码头 • 8.0折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50567,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | 上野小路 • 寿司7.0折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:55822,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    B1F | 纽芝兰冰淇淋 • 单球仅8元
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50555,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    3F | 圣杰士披萨阳光餐厅 • 2款美食半价
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50565,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    B1F | 90°炭烧咖啡 • 饮品8.8折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:52941,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    1F | 通天阁 • 综合刺身套餐118元
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50566,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | 京都一品 • 消费立减10元
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50553,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    1F | 重庆鸡公煲 • 8.8折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50571,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    3F | 火宴山时尚涮烤 • 8.8折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50564,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    1F | 宝龙蹄膀店 • 8.8折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:52937,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    1F | 吉鑫记 • 套餐特价仅58元
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50559,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | 百度烤肉 • 自助餐低至43元
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50563,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    1F | 渔家乐斑鱼火锅 • 斑鱼买2斤送1斤
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50556,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    1F | 两岸咖啡 • 特价套餐仅88元
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:55371,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    B1F | 牛角烧烤 • 9.0折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50558,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | 潇肴江湖 • 8.8折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50561,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    B1F | 女仆革命 • 消费满30立减5元
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:52940,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    B1F | 一心一客 • 满20元立减2元
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50554,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    1F | 快嘴网 • 8.8折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50562,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    5F | 北角咖啡 • 鸡尾酒9.0折
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50557,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    B1F | 金饭庄 • 8.8折特权
                                </a>
                            </li>
                        </ul>
                        <a class="turn on" data-scroll-flag="lstname1" style="" data-clkbinded="1">
                            展开全部25条会员特权
                        </a>
                        <a class="turn off" data-scroll-flag="lstname1" data-clkbinded="1" style="display: none; ">
                            收起
                        </a>
                    </div>
                </article>
                <article class="shoptype" id="type2">
                    <h1 style="background-image: url(./misc/images/icons.png); -webkit-background-size: 15px 300px; background-size: 15px 300px; background-position: 0px -30px; background-repeat: no-repeat no-repeat; ">
                        时尚购物
                    </h1>
                    <div class="lst">
                        <ul id="lstname2">
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50536,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5">
                                <a>
                                    4F | 巴黎香榭 • 6.5折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:58266,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5">
                                <a>
                                    3F | 百合坊 • 7.0折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:58264,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    1F | 歌纳雅 • 7.5折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50539,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | ZERO哲若 • 8.5折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:58265,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | 格调女装 • 8.0折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50537,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | A²时尚男装 • 8.0折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50538,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | Ori Gin原点 • 8.0折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50532,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    1F | MAMAS玛丽露 • 享双重折扣
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:58312,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    2F | 吉田耀司 • 折上再享9.5折
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50546,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | 思薇婚纱 • 租借婚纱3.5折
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:58263,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | 格林 • 8.5折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:57788,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    2F | 美舍雅阁 • 赠价值15元面膜一片
                                </a>
                            </li>
                        </ul>
                        <a class="turn on" data-scroll-flag="lstname2" style="" data-clkbinded="1">
                            展开全部12条会员特权
                        </a>
                        <a class="turn off" data-scroll-flag="lstname2" data-clkbinded="1" style="display: none; ">
                            收起
                        </a>
                    </div>
                </article>
                <article class="shoptype" id="type3">
                    <h1 style="background-image: url(./misc/images/icons.png); -webkit-background-size: 15px 300px; background-size: 15px 300px; background-position: 0px -60px; background-repeat: no-repeat no-repeat; ">
                        休闲娱乐
                    </h1>
                    <div class="lst">
                        <ul id="lstname3">
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50534,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5">
                                <a>
                                    3F | 紫罗兰造型 • 剪发套餐28/次
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:58285,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5">
                                <a>
                                    3F | 美姿城美容 • 面部细胞水密码仅9.9元
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:55369,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    2F | 伊芙悦 • 修手+极速手护特价20元
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:58284,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    3F | 紫罗兰造型 • 剪发套餐28元/次
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:55370,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    3F | 海豚湾 • 可卸光疗特价35元
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50550,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | 新创艺造型 • 低至5.0折
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50547,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    3F | 乐乐美甲 • 48元享纯色光疗
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50544,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    3F | 艾尚秀美甲沙龙 • 快速有氧光疗特价
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50551,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    1F | 大拇指美甲 • 9.0折特权
                                </a>
                            </li>
                            <li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50543,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5" class="r" style="display: none; ">
                                <a>
                                    4F | 艾薇儿主题婚纱摄影 • 立减1000元
                                </a>
                            </li>
                        </ul>
                        <a class="turn on" data-scroll-flag="lstname3" style="" data-clkbinded="1">
                            展开全部10条会员特权
                        </a>
                        <a class="turn off" data-scroll-flag="lstname3" data-clkbinded="1" style="display: none; ">
                            收起
                        </a>
                    </div>
                </article>
            </div>
            <footer style="height:20px;">
            </footer>
        </div>
    </body>

</html>