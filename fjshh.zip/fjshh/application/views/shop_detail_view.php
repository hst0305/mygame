<!DOCTYPE html>
<html lang="zh-CN">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;">
        <meta name="format-detection" content="telephone=no">
        <title>
           <?php echo $detail['name']; ?>
        </title>
        <base href="<?php echo "$base"; ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo "$base/$css";?>">
        </script>
        <style>
            abbr,article,aside,audio,canvas,datalist,details,dialog,eventsource,figure,figcaption,footer,header,hgroup,mark,menu,meter,nav,output,progress,section,small,time,video{display:block;}
        </style>
    </head>
    <body id="powerPage" class="" style="height: auto; ">
        <div id="mappContainer">
            <header class="use_hd">
                <div class="hinn box">
                    <div class="inner">
                        <h1>
                             <?php echo $detail['name']; ?>
                        </h1>
                        <!-- 
                        <time datetime="2012-12-31">
                            截止日期: <?php echo $detail['deadline']; ?>
                        </time>
                         -->
                    </div>
                </div>
            </header>
			<?php echo $detail['tip']; ?>
			  <!-- 
            <aside class="use_note asd2 inner">
                <b>
                    生活汇客服电话：
                </b>
                <ul>
                    <li>
                        <a class="autotel" href="tel:400-600-7660">
                            400-600-8888
                        </a>
                    </li>
                </ul>
            </aside>
             -->
            <img id="pview" width="104" style="display:none;position:absolute;left:39px;">
        </div>
    </body>

</html>