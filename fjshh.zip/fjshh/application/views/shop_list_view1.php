<!DOCTYPE html>
<html lang="zh-CN">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;">
        <meta name="format-detection" content="telephone=no">
        <title>
            	生活汇
        </title>
        <base href="<?php echo "$base"; ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo "$base/$css";?>">
        <script src="<?php echo "$base";?>/misc/wei_webapp_v3.5.9.js">
        </script>
        <style>
            abbr,article,aside,audio,canvas,datalist,details,dialog,eventsource,figure,figcaption,footer,header,hgroup,mark,menu,meter,nav,output,progress,section,small,time,video{display:block;}
        </style>
    </head>
    <body id="" class="">
<script>
var ua = navigator.userAgent+navigator.platform;
function showBanner(){
	if(document.cookie.search('palmnews_banner=1') != -1 || ua.search('Android') == -1){
		return false;
	}
	var banner_box=document.getElementById('top_banner');
	banner_box.style.display='block';
}

function openLink(){
//	var iosdurl = '';
	var androiddurl = 'http://sina.cn/j/?k=151';
	if(ua.search('Android')!= -1){
		window.open(androiddurl);
	}
	clsBanner();
}
function clsBanner(){
    var banner_box=document.getElementById('top_banner');
    banner_box.style.display='none';
    setBannerCookie();
}
function setBannerCookie(){
	var Days = 1000;
	var exp = new Date();
	exp.setTime(exp.getTime() + Days*24*60*60*1000);
	document.cookie = "palmnews_banner=1;expires=" + exp.toGMTString()+";domain=sina.cn";
	document.cookie = "palmnews_banner=1;expires=" + exp.toGMTString()+";domain=3g.sina.com.cn";
}
showBanner();
</script>
	<!--页头信息-->
	<div class="headbox">
		<div class="logoarea">
			<h2><a href="<?php echo "$base/$home";?>" title="生活汇"></a></h2>
			<div class="navlist">
				<div class="head_nav"><!--staticdump begin--><a class="weather" href="http://weather1.sina.cn/dpool/weather_new/forecast_new.php?city=福州&vt=4"><span style="background-image:url(http://u1.sinaimg.cn/upload/cms/image/weather/h/qing.png)"></span>福州<em>15°<code></code>5°</em></a><!--staticdump end--></div>
			</div>
		</div>
		<div class="headnav">
			<p>
				<a href="<?php echo "$base/$home";?>" title="首页">首页</a><a href="<?php echo "$base/$eat";?>"title="餐饮">餐饮</a><a href="<?php echo "$base/$fun";?>" title="娱乐">娱乐</a><a href="<?php echo "$base/$service";?>" title="服务">服务</a><a href="<?php echo "$base/$area";?>" title="商圈">商圈</a>
			</p>
		</div>
	</div>
	<!--推广位-->
            <div class="vs2" id="shop_lst" style="">			
                <article class="shoptype" id="type1">
                    <h1 style="background-image: url(<?php echo "$base";?>/misc/images/icons.png); -webkit-background-size: 15px 300px; background-size: 15px 300px; background-position: 0px 0px; background-repeat: no-repeat no-repeat; ">
                        抢鲜汇
                    </h1>
                    <div class="lst">
                        <ul id="lstname1">
                          <?php 
  foreach ($category2 as $row)
	{
		?>
		<li data-ajax-params="{&quot;sid&quot;:&quot;6274449498546729170&quot;,&quot;bcid&quot;:50568,&quot;wticket&quot;:&quot;b9662cd6f4dac79f97c2a3a755ed1b04&quot;,&quot;ticket&quot;:&quot;AUiPlDsBAADwts1Q&quot;,&quot;qrcode&quot;:&quot;13484743302481&quot;}"
                            data-ajax-act="5">
                                <a href='<?php echo "$base/";?>index.php/shopDetail/index/<?php echo  $row['detail_id'];?>'>
                                   <?php echo $row['name'];?>
                                </a>
                            </li>
		  <?php 
	}
   ?> 
                            
                        </ul>
                        <a class="turn on" href='<?php echo "$base/";?>index.php/shopList/index/0/3''>
                            点击查看更多
                        </a>
                    </div>
                </article>
            </div>
            <footer style="height:20px;">
            </footer>
        </div>
    </body>

</html>