<!DOCTYPE html>
<html lang="zh-CN">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;">
        <meta name="format-detection" content="telephone=no">
        <title>
            	生活汇
        </title>
        <base href="<?php echo "$base"; ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo "$base/$css";?>">
        <script src="./misc/wei_webapp_v3.5.9.js">
        </script>
        <style>
            abbr,article,aside,audio,canvas,datalist,details,dialog,eventsource,figure,figcaption,footer,header,hgroup,mark,menu,meter,nav,output,progress,section,small,time,video{display:block;}
        </style>
    </head>
    <body id="" class="">
	<!--页头信息-->
	<div class="headbox">
		<div class="logoarea">
			<h2><a href="http://sina.cn/?pos=108&vt=4" title="生活汇"></a></h2>
			<div class="navlist">
				<div class="head_nav"><!--staticdump begin--><a class="weather" href="http://weather1.sina.cn/dpool/weather_new/index.php?pos=108&vt=4"><span style="background-image:url(http://u1.sinaimg.cn/upload/cms/image/weather/h/qing.png)"></span>福州<em>-5°<code></code>-15°</em></a><!--staticdump end--></div>
			</div>
		</div>
		<div class="headnav">
			<p>
				<a href="<?php echo "$base/$css";?>" title="首页">首页</a><a href="http://finance.sina.cn/?sa=t60d13v512&pos=108&vt=4" title="餐饮">餐饮</a><a href="http://mil.sina.cn/?pos=108&vt=4" title="娱乐">娱乐</a><a href="http://blog.sina.cn/?pos=108&vt=4" title="服务">服务</a><a href="http://sports.sina.cn/?pos=108&vt=4" title="商圈">商圈</a>
			</p>
		</div>
	</div>
	<!--推广位-->
            <div class="vs2" id="shop_lst" style="">
            暂未开放
            </div>
            <footer style="height:20px;">
            </footer>
        </div>
    </body>

</html>